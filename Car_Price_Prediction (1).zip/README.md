# Car Price Prediction

## Synopsis
This project focuses on predicting the price of a used or new car based on information such as brand, year, kilometers driven, fuel type, engine size, number of owners, and transmission. Students analyze the data and build a regression model to estimate car prices.

## Objectives
- Explore car information.
- Identify factors affecting car prices.
- Clean and prepare the dataset.
- Train a regression model.
- Predict car prices.
- Compare predicted and actual prices.

## Tools
Python, Pandas, Matplotlib, Scikit-learn

## Dataset Features
- car_id
- brand
- year
- kilometers_driven
- fuel_type
- engine_size_l
- number_of_owners
- transmission
- price

Target:
- price — predicted car price

## Data Preparation
- Loaded the dataset using Pandas.
- Checked for missing values.
- Filled missing numerical values using median values.
- Filled missing categorical values using the most frequent value.
- Standardized numerical features.
- One-hot encoded categorical features.
- Split the dataset into training and testing sets.

## Machine Learning Algorithm
Linear Regression is used as the regression model.

## Evaluation
The program calculates:
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- R² Score
- Actual vs predicted price comparison
- Predicted price for a new car
- Important factors based on regression coefficients

It also generates:
- `kilometers_vs_price.png`
- `actual_vs_predicted.png`

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python car_price_prediction.py

## Dataset Note
The included car-price dataset is synthetic and intended for educational/classroom machine-learning practice. It does not contain real vehicle sales records.
